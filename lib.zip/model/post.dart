class Post{
  String title;
  String postdate;
  String content;

  Post(this.title, this.postdate, this.content);
}